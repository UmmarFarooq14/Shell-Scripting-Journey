# Shell Scripting for Files & Directories:
# Error Handling

#!/bin/bash
echo "=== Script Starting ==="
#ls /nonexistent-directory
current_date=`date`
echo $?
echo "The current date is:$current_date"
if [ $? -eq 0 ]
then 
    echo "Directory Exits."
else
    echo "Directory Doesn't Exit."
fi 
  echo "=== Script Finished ==="


# Check the File Exist or not using Script.
#!/bin/bash
echo " === Script Starting ==="
file="nonexistent-file.txt"
if [ -f "$file" ]
then
    echo "The file Exist."
else 
    echo "The file doesn't exist."
fi 
  echo " === Script Ending ==="


#Trap For Handling Signals

#!/bin/bash
echo " === Script Starting ==="
cleanup() {
    echo "cleaning up..."
    exit 1
}
trap cleanup INT 
echo "Running..."
sleep 10
echo " === Script Ending ==="


# List files and directories

#!/bin/bash 
ls -l | gerp -i "txt"


#Count the number of lines in a file

#!/bin/bash
cat filename | wc -l

#Count the number of characters in a file

#!/bin/bash
cat filename | wc -c

#Count the number of  words in a file

#!/bin/bash
cat filename | wc -w 

#Redirect Output to a File

#!/bin/bash
ls >file_list.txt

#Append Output to a File

#!/bin/bash
echo "new content" >>file_list.txt

#Redirect Input from a File

sort < unsorted.txt > sorted.txt 

#Combining Redirection and Piping 

cat file.txt | grep "keyword" > filtered.txt 

#Using /dev/null to Discard Output

ls non_existent_folder 2> /dev/null 



#Shell Scripting using Debugging

#!/bin/bash
name="John"  
age=25  
echo "Debug: Starting script..."  
sleep 5
echo "Debug: Name is $name"  
echo "Debug: Age is $age"  
result=$((age * 2))  
sleep 5
echo "Debug: Result is $result"  
echo "Debug: Script completed." 


#Using set -x and set -e

#!/bin/bash
set -x
set -e
name="John"  
age=25  
echo "Debug: Starting script..."  
echo "Debug: Name is $name"  
echo "Debug: Age is $age"  
result=$((age * 2))  
echo "Debug: Result is $result"  
echo "Debug: Script completed." 


# Running Commands in a Subshell

#!/bin/bash
echo "Current working directory: $(pwd)"  
echo "Number of files in /tmp: $(ls /tmp | wc -l)" 


#Running a Background Process

#!/bin/bash 
sleep 5 & 
echo "Background process started."
wait
echo "Background process ended."


# Running a Foreground Process 

#!/bin/bash
echo "Enter a name:"
read name
echo "Hello, $name!."


#Combining Subshells and Process Control 

#!/bin/bash
(  
echo "Subshell working directory: $(pwd)"  
sleep 3 &  
echo "Subshell background process started."  
wait  
echo "Subshell background process completed."  
)  
echo "Main shell continues." 



