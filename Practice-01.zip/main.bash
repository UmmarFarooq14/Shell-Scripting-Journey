# Basic Scripting in Shell
<<comment
#/bin/Bash
echo -n "Hello! Welcome to the world of Shell Scripting."

#!/bin/Bash
echo "Hello! Enter your name?"
read name
echo "Nice to meet you, $name"

# Installation of Docker
#!/bin/Bash
sudo yum(or)dnf update -y
sudo yum(or)dnf Install docker -y
sudo usermod-aG docker $USER
sudo systemctl status docker
sudo systemctl enable docker
docker --version

# Scripting using variable
#!/bin/Bash
name="Shaik Ummar Farooq."
age=23
echo "My name is $name & age is $age."


# If we want to take i/p from user 
#!/bin/bash
echo "Enter your name:"
read name
echo "Enter your age:"
read age
echo "My name is $name & age is $age."


#Arthametic Operations
#!/bin/bash 
x=10
y=20
sum=$((x+y))
echo "The sum is: $sum"


#If we want to i/p from user
#!/bin/bash 
echo "enter the first value:"
read x 
echo "enter the second value:"
read y 
sum=$((x+y))
echo "The sum of $x & $y is: $sum"


# If we want execute five then we use loops
#!/bin/bash 
for((i=0;i<=5;i++))
do 
  echo "enter the first value:"
  read x 
  echo "enter the second value:"
  read y 
  sum=$((x+y))
  echo "The sum of $x & $y is: $sum"
done

# Concatenation in Shell Scripting
#!/bin/bash 
greeting="Hello"
subject="World"
message="$greeting! $subject"
echo "The message is: $message"

#!/bin/bash
fname="Shaik"
mname="Ummar"
lname="Farooq"
Fullname="$fname $mname$lname"
echo "My name is:$Fullname"


#String Length in Shell Scripting
#!/bin/bash
name="Shaik UmmarFarooq"
lengthofstr=${#name}
echo "The length of the string is: $lengthofstr"


#Substring in Shell Scripting
#!/bin/bash
name="Shaik Ummar Farooq"
substring=${name:0:8}
echo "The substring in name is:$substring"


# Shell Scripting using Current Date.
#!/bin/bash 
current_date=`date`
echo "The current date is:$current_date"

# Shell Scripting using Current time 
#!/bin/bash
time_stamp=$(date +%H:%M:%S)
echo "The current time is:$time_stamp"


#Escaping Character
#!/bin/bash
special_character='\&'
echo "The variabke is:$special_character"

comment


