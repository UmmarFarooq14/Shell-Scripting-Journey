<<comment
# Input with prompting
#!/bin/bash 
read -p "Enter your favourite color:" color
echo "My Favourite color is: $color"


# Prompting using securing the password
#!/bin/bash
read -s -p "Enter Your Password:" Password
echo "My Password is: $Password"


# Prompting using timeout 
#!/bin/bash
read -t 5 -p "Enter your name:" name
echo "My name is $name"


# Conditional Statements
#!/bin/bash
read -p "enter the age:" age 
if [ $age -gt 18 ]
then
    echo "He/She is eligible for vote."
else
    echo "He/She not eligible for vote."
fi


# Comparing three to check which number is bigger
#!/bin/bash
read -p "Enter the first number:" a 
read -p "Enter the second number:" b
read -p "Enter the third number:" c 
if [ $a -gt $b] && [ $a -gt $c ]
then 
    echo " a:$a is a bigger number than b:$b & c:$c."
elif  [ $b -gt $a ] && [ $b -gt $c ]
then 
    echo "b:$b is a bigger number than a:$a & c:$c."
else
   echo "c:$c is bigger number than a:$a & b:$b"
fi


#Switch Case in shell Scripting
#!/bin/bash
fruit="Dragon"
case $fruit in "apple")
echo "It is a Banana.";;
"Banana")
echo "It is a apple.";;
"pineapple")
echo "It is a pineapple.";;
*)
echo "Unknown fruit.";;
esac


# Scripting Using Loops
#!/bin/bash
name="Shaik Ummar Farooq"
for i in {1..5}
do 
  echo "$name"
done


#Scripting using to print multiplications
#!/bin/bash
for((i=1;i<=20;i++))
do
  echo "The multiplications of $i is:"
  for((j=1;j<=10;j++))
  do 
    echo "$i * $j == $((i*j))"
  done 
    echo "=== It's End ==="
done
comment


#Using while loop
#!/bin/bash
count=1 
while [ $count -le 10 ]
do 
  echo "The Count is:$count"
  ((count++))
done
   

