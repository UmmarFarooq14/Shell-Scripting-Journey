# Scripts for Interview Purpose

# Script for Backup 
#!/bin/bash 
backup_dir="path of the directory"
source_dir="path of the directory"
time_stamp=$(date +%Y%M%D_%H%M%S)
tar -zcvf "$backup_dir/backup_time_stamp.tar.gz" "$source_dir"
echo $? 
if [ $? -eq 0 ]
then 
    echo "Backup successfull: $backup_dir is taken from $source_dir."
else
    echo "Backup Failed."


#Find & Replace

# !/bin/bash
string="Hello, World! Hi"
find="Hello"
replace="Hlo"
result=${string//$find/$replace}
echo "Before replacing the string is:$string"
echo "After replacing the string is:$result"


# Find $ Replace in Files

#!/bin/bash
search_string="word_name"
replace_string="newword_name"
file="/path/to/files/directory"
find "$file" -type f -exec sed -i "s/$search_string/$replace_string/g" {} +
echo "Find & Replace Completed."



# Monitoring System Resources with Shell

#!/bin/bash
while true
do 
  clear
  echo "System Resource Monitoring"
  echo "=========================="
  echo "CPU Usage"
  top -n 1 -b |grep -i "filename"
  sleep 5
  echo -e "\n Memory Usage"
  sleep 5
  free -m 
  echo -e "Disk space Usage"
  sleep 5
  df -h 
  
done


#Parsing & Text Processing

#!/bin/bash
Shaik UmmarFarooq |23|Devops Engineer # create a separe file & enter the data
while IFS='|' read -r name age profession;
do 
  echo "Name:"$name
  echo "Age:"$age
  echo "Profession:"$profession
  sleep 5
  echo "===="
done<


#File Exist or not

#!/bin/bash
File="/path/to/your/file.txt"
if [ -f "$File"  ]
then 
    echo "$File is Exist."
else
    echo "$File Doesn't Exist."
fi


#Check Even or Odd 

#!/bin/bash 
read -p "Enter the number:" num 
if [ $((num%2)) -eq 0 ]
then 
    echo "$num is Even."
else 
    echo "$num id Odd."
fi

# Fibanocci Series Using Shell

#!/bin/bash
read -p "Enter the number:" num 
echo -e "The Fibonacci Series of $num is:"
a=0
b=1
for((i=2;i<=10;i++))
do 
 echo "$a"
 nt=$((a+b))
 a=$b 
 b=$nt
 echo "==="
done

