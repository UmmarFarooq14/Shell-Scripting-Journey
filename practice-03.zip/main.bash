# Shell Script Using a functions
# Sum of two numbers using functions.
sum_two() {
    a=10
    b=30
    sum=$((a+b))
    echo "The sum of $a & $b is: $sum"
}
sum_two

#!/bin/bash
greet() {
    echo "Hello! Welcome to world of Devops."
}
greet


#Function Argument with return Value
#!/bin/bash
print_args() {
    read  -p "enter the argument: $1" 
    read -t 5 -p "enter the arguments: $2"
}
print_args "Hello" "World"


#String  Manipulation in Shell Scripts:
#!/bin/bash
string1="Hello,"
string2="World!"
result="$string1 $string2"
echo "The concadination of string is: $result"


#Substring
#!/bin/bash
string="Hello, World!"
length=${string:7:13}
echo "The length of the string is:$length"


#String Search & Replace
#!/bin/bash
string="Hello, World! Hello"
search="Hello"
replace="Hi"
result=${string//$search/$replace}
echo "The result is: $string"
echo "The result after replacing the stirng is:$result"


#Arrays in Shell Scripting:
#!/bin/bash
fruits=("apple" "banana" "pineapple" "Dragon" "kiwi")
echo "The 1st fruit:${fruits[0]}"
echo "The 2nd fruit:${fruits[1]}"
echo "The 3rd fruit:${fruits[2]}"
echo "The 4th fruit:${fruits[3]}"
echo "The 5th fruit:${fruits[4]}"


#Array length in shell Scripting
#!/bin/bash
fruits=("apple" "banana" "pineapple" "Dragon" "kiwi")
echo "The length of the array is: ${#fruits}"


#Arrays Using Loops
#!/bin/bash
fruits=("apple" "banana" "pineapple" "Dragon" "kiwi")
for fruits in args
do 
 echo "The list of fruits is:${fruits[*]}"
done


#Adding element to Array 
#!/bin/bash
fruits=("apple" "banana" "pineapple" "Dragon" "kiwi")
echo "The list of elements in array is:${fruits[*]}"
fruits+=("Mango")
echo "The list of elements in array is:${fruits[*]}"

#Script to print command line arguments
#!/bin/bash
echo "Script name:$0"
echo "First arguments: $1"
echo "Second argument: $2"
echo "Total Number of elements:$#"
echo "All Arguments as List:$@"
echo "All Arguments as string:$*"
echo "To check the command execute successfully or not:$?"

